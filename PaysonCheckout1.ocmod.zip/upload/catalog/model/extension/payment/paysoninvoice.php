<?php

class ModelExtensionPaymentPaysoninvoice extends Model {
    public function getMethod() {
        return;
        // DEPRECATED
    }   
}
?>