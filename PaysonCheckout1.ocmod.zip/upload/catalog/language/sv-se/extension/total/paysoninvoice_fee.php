<?php
$_['text_paysoninvoice_fee'] = 'Payson fakturaavgift';
?>