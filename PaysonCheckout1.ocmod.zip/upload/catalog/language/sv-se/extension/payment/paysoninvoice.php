<?php

$_['text_title']   = '<img src="https://www.payson.se/sites/all/files/images/external/payson_faktura.png" style="width:140px;height:55px;clear:right" alt="Payson Faktura" title="Paysoninvoice" />  - (Fakturaavgift inkl moms: %s SEK)';
$_['text_denied'] = 'Betalningen blev nekad.';
$_['text_invoice_terms']  = '<div style="padding: 3px; margin-bottom: 5px;"><h2>Fakturavillkor <img src="catalog/view/theme/default/image/paysoninvoice.png" style="display: block; float: right;" /></h2>'.utf8_encode("Om du v&auml;ljer att betala med Paysonfaktura s&aring; tillkommer en avgift om %sSEK inkl moms. Betalningsvillkor &auml;r 14 dagar och fakturan kommer att s&auml;ndas separat med e-post till den e-postadress Du anger. F&ouml;r att betala mot Paysonfaktura m&aring;ste Du ha fyllt 18 &aring;r och vara folkbokf&ouml;rd i Sverige samt godk&auml;nnas i den kreditpr&ouml;vning som genomf&ouml;rs vid k&ouml;pet.").'</div>';
$_['text_payson_payment_method'] = ' Testa med en annan betalningsmetod.';
$_['text_payson_payment_error'] = 'Ett fel har uppstått. Vänligen försök igen eller pröva med en annan betalmetod';
$_['text_wait'] = 'Vänligen vänta....';
?>