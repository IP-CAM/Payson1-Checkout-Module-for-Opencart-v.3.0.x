<?php
class ControllerExtensionPaymentPaysoninvoice extends Controller {
    public function index() {
        // DEPRECATED
    }
}
?>