<?php

class ControllerExtensionPaymentPaysondirect extends Controller {

    private $testMode;
    private $api;
    private $isInvoice;
    private $data = array();

    const MODULE_VERSION = 'paysoncheckout1.0_opencart-3-0-0-0';

    function __construct($registry) {
        parent::__construct($registry);
        $this->testMode = ($this->config->get('payment_paysondirect_mode') == 0);
        $this->api = $this->getAPIInstance();
    }

    public function index() {

        $constraints = $this->getConstrains($this->config->get('payment_paysondirect_payment_method'));
        if (in_array(FundingConstraint::INVOICE, $constraints)) {
        //if (in_array(FundingConstraint::INVOICE, $constraints) && strtoupper($this->session->data['currency']) == 'SEK') {
            $this->isInvoice = true;
            $this->data['isInvoice'] = true;
        }


        $this->load->language('extension/payment/paysondirect');
        $this->data['button_confirm'] = $this->language->get('button_confirm');
        $this->data['text_wait'] = $this->language->get('text_wait');

        //Invoice fee terms
        if ($this->isInvoice && $this->session->data['currency'] == 'SEK') {
            $Fee = $this->config->get('total_paysoninvoice_fee_fee');
            $this->data['text_invoice_terms_with_fee'] = sprintf($this->language->get('text_invoice_terms'), ($this->isInvoice) ? $Fee : 0);
        }
        return $this->load->view('extension/payment/paysondirect', $this->data);

    }

    public function confirm() {
        $this->setupPurchaseData();
    }

    private function setupPurchaseData() {
        $this->load->language('extension/payment/paysondirect');
        $this->load->model('checkout/order');
        $order_data = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        $this->data['store_name'] = html_entity_decode($order_data['store_name'], ENT_QUOTES, 'UTF-8');
        //Payson send the responds to the shop
        $this->data['ok_url'] = $this->url->link('extension/payment/paysondirect/returnFromPayson', '', true);
        $this->data['cancel_url'] = $this->url->link('checkout/checkout', '', true);
        $this->data['ipn_url'] = $this->url->link('extension/payment/paysondirect/paysonIpn', '', true);


        $this->data['order_id'] = $order_data['order_id'];
        $this->data['amount'] = $this->currency->format($order_data['total'] * 100, $order_data['currency_code'], $order_data['currency_value'], false) / 100;
        $this->data['currency_code'] = $order_data['currency_code'];
        $this->data['language_code'] = $order_data['language_code'];
        $this->data['salt'] = md5($this->config->get('payment_paysondirect_secure_word')) . '1-' . $this->data['order_id'];
        //Customer info
        $this->data['sender_email'] = $order_data['email'];
        $this->data['sender_first_name'] = html_entity_decode($order_data['firstname'], ENT_QUOTES, 'UTF-8');
        $this->data['sender_last_name'] = html_entity_decode($order_data['lastname'], ENT_QUOTES, 'UTF-8');
        $this->data['countrycode'] = html_entity_decode($order_data['payment_country'], ENT_QUOTES, 'UTF-8');

        //Call PaysonAPI        
        $result = $this->getPaymentURL();

        $returnData = array();

        if ($result["Result"] == "OK") {
            $returnData["paymentURL"] = $result["PaymentURL"];
        } else {
            $returnData["error"] = $this->language->get("text_payson_payment_error");
        }       
        
        $this->response->setOutput(json_encode($returnData));

    }
    //Returns from Payson after the transaction has ended.
    public function returnFromPayson() {
        
        $this->load->language('extension/payment/paysondirect');
        $paymentDetails = null;


        if (isset($this->request->get['TOKEN'])) {

            $secureWordFromShop = md5($this->config->get('payment_paysondirect_secure_word')) . '1';
            $paymentDetailsResponse = $this->api->paymentDetails(new PaymentDetailsData($this->request->get['TOKEN']));

            if ($paymentDetailsResponse->getResponseEnvelope()->wasSuccessful()) {
                $paymentDetails = $paymentDetailsResponse->getPaymentDetails();

                // Get the secure word as hash and order id
                $trackingFromDetails = explode('-', $paymentDetails->getTrackingId());

                if ($secureWordFromShop != $trackingFromDetails[0]) {
                    $this->writeToLog($this->language->get('Call doesnt seem to come from Payson. Please contact store owner if this should be a valid call.'), $paymentDetails);
                    $this->paysonApiError($this->language->get('Call doesnt seem to come from Payson. Please contact store owner if this should be a valid call.'));
                    return false;
                }

                if ($this->handlePaymentDetails($paymentDetails, $trackingFromDetails[1])) {
                    $this->response->redirect($this->url->link('checkout/success'));
                } else {
                    $this->response->redirect($this->url->link('checkout/checkout'));
                }
            } else {
                $this->logErrorsAndReturnThem($paymentDetailsResponse);
            }
        } else {
            $this->writeToLog("Returned from Payson without a Token");
        }
    }

    //get invoice fee + tax 
    public function getInvoiceFee() {
        $this->load->language('extension/payment/paysondirect');
        $this->load->model('checkout/order');
        $this->load->language('extension/total/paysoninvoice_fee');
		$fee = $this->config->get('total_paysoninvoice_fee_fee');
        if ($this->config->get('total_paysoninvoice_fee_tax_class_id')) {
			$tax = $this->config->get('total_paysoninvoice_fee_tax_class_id');
			$tax_rule_id = $this->db->query("SELECT tax_rate_id FROM `" . DB_PREFIX . "tax_rule` where  tax_class_id='" . $tax . "'");
			$invoiceFeeTax = $this->db->query("SELECT rate FROM `" . DB_PREFIX . "tax_rate` where  tax_rate_id='" . $tax_rule_id->row['tax_rate_id'] . "'");
			$invoiceFeeTax = ($invoiceFeeTax->row['rate'] / 100) + 1;
			$fee *= $invoiceFeeTax;
        }
        return $fee;
    }
    /**
     * 
     * @param PaymentDetails $paymentDetails
     */
    private function handlePaymentDetails($paymentDetails, $orderId = 0, $ipnCall = false) {
        $this->load->language('extension/payment/paysondirect');
        $this->load->model('checkout/order');
        $this->load->language('extension/total/paysoninvoice_fee');
        $paymentType = $paymentDetails->getType();
        $transferStatus = $paymentDetails->getStatus();
        $invoiceStatus = $paymentDetails->getInvoiceStatus();
        $orderId = $orderId ? $orderId : $this->session->data['order_id'];

        $order_info = $this->model_checkout_order->getOrder($orderId);
        if (!$order_info) {
            return false;
        }

        $amount = $paymentDetails->getAmount();

   		$total = $amount;


        $this->storeIPNResponse($paymentDetails, $orderId);

        $succesfullStatus = null;

        if ($paymentType == "TRANSFER" && $transferStatus == "COMPLETED") {
            $succesfullStatus = $this->config->get('payment_paysondirect_order_status_id');
        }

        if ($paymentType == "INVOICE" && $invoiceStatus == "ORDERCREATED") {
            $succesfullStatus = $this->config->get('payment_paysondirect_invoice_status_id');

            $invoiceFee = $this->db->query("SELECT code FROM `" . DB_PREFIX . "order_total` where code='paysoninvoice_fee' and order_id='" . $orderId . "'");

            if ($invoiceFee->num_rows == 0) {

                $this->db->query("INSERT INTO `" . DB_PREFIX . "order_total` (order_id, code, title, value, sort_order)
                    VALUES('" . $orderId . "', "
                        . "'paysoninvoice_fee',  "
                        . "'" . $this->language->get('text_paysoninvoice_fee') . "',  "
                        . "'" . $this->getInvoiceFee() . "',  "
                        . "'" . 2 . "')");

                $this->db->query("UPDATE `" . DB_PREFIX . "order_total` SET
                                value  = '" . $total . "'
                                WHERE order_id      = '" . $orderId . "' 
                                and code = 'total'");
            }

            $this->db->query("UPDATE `" . DB_PREFIX . "order` SET 
                                shipping_firstname  = '" . $paymentDetails->getShippingAddressName() . "',
                                shipping_lastname   = '',
                                shipping_address_1  = '" . $paymentDetails->getShippingAddressStreetAddress() . "',
                                shipping_city       = '" . $paymentDetails->getShippingAddressCity() . "', 
                                shipping_country    = '" . $paymentDetails->getShippingAddressCountry() . "', 
                                shipping_postcode   = '" . $paymentDetails->getShippingAddressPostalCode() . "',
                                total                   = '" . $total . "',
                                payment_code            = 'paysoninvoice'
                                WHERE order_id      = '" . $orderId . "'");
        }

        if ($succesfullStatus) {
            if (!$order_info['order_status_id']) {
                $comment = "";
                if($this->testMode){
                    $comment .= "Payson-ref: " . $paymentDetails->getPurchaseId() . "\n\n";
                    $comment .= "Payson status: " . $transferStatus . "\n\n";
                    $comment .= "Payson invoice status: " . $invoiceStatus . "\n\n";
                    $comment .= "Paid Order: " . $orderId;
                    $this->testMode ? $comment .= "\n\nPayment mode: " . 'TEST MODE' : '';
                }
                
                $this->model_checkout_order->addOrderHistory($orderId, $succesfullStatus, $comment, false, true);
            } else {
                //$this->model_checkout_order->update($orderId, $succesfullStatus);
            }
            return true;
        }

        if ($transferStatus == "ERROR" || $transferStatus == "EXPIRED"||$transferStatus == "DENIED") {
            if ($ipnCall) {
                $this->writeToLog('Order was denied by payson.&#10;Purchase type:&#9;&#9;' . $paymentType . '&#10;Order id:&#9;&#9;&#9;&#9;' . $orderId, $paymentDetails);
            }
            $this->paysonApiError($this->language->get('text_denied'));
            return false;
        }

        $this->response->redirect($this->url->link('checkout/checkout'));
    }

    private function getConstrains($paymentMethod) {
        $constraints = array();
        $opts = array(
            0 => array(''),
            1 => array('card'),
            2 => array('bank'),
            3 => array('invoice'),
            4 => array('bank', 'card'),
            5 => array('bank', 'invoice'),
            6 => array('card', 'invoice'),
            7 => array('bank', 'card', 'invoice'),
        );
        $optsStrings = array('' => FundingConstraint::NONE, 'bank' => FundingConstraint::BANK, 'card' => FundingConstraint::CREDITCARD, 'invoice' => FundingConstraint::INVOICE);
        if ($opts[$paymentMethod]) {
            foreach ($opts[$paymentMethod] as $methodStringName) {
                $constraints[] = $optsStrings[$methodStringName];
            }
        }
        return $constraints;
    }

    private function getPaymentURL() {
        require_once 'payson/paysonapi.php';

        $this->load->language('extension/payment/paysondirect');
        $constraints = $this->getConstrains($this->config->get('payment_paysondirect_payment_method'));
        $orderItems = $this->getOrderItems();
        
        $invoiceFee = $this->getInvoiceFee();
        if (in_array(FundingConstraint::INVOICE, $constraints)) {
//          If order amount is less than 30, then remove invoice option from funding_array            
            if ($this->data['amount'] < 30) {
                $key = array_search(FundingConstraint::INVOICE, $constraints);
                unset($constraints[$key]);
            }

//          If currency not SEK, then remove invoice option from funding_array
            if ($this->currencyPaysondirect() != 'SEK') {
                $key = array_search(FundingConstraint::INVOICE, $constraints);
                unset($constraints[$key]);
            }
//          If not order not from Sweden, remove invoice option from funding_array
            $countryCode = trim(strtoupper($this->data['countrycode']));
            if($countryCode!=='SWEDEN' && $countryCode!=='SVERIGE'){                    
               $key = array_search(FundingConstraint::INVOICE, $constraints);
                unset($constraints[$key]); 
            }         
        }
//      If Invoice still exist after these checks then add InvoiceFee to order.
        if (in_array(FundingConstraint::INVOICE, $constraints)) {
            $this->data['amount'] += $invoiceFee;
        }
  
        $user = explode('##', $this->config->get('payment_paysondirect_user_name'));
        $store = $this->config->get('config_store_id');
        $userName = $user[$store];
        $receiver = new Receiver(trim($userName), $this->data['amount']);

        $sender = new Sender($this->data['sender_email'], $this->data['sender_first_name'], $this->data['sender_last_name']);

        $receivers = array($receiver);
        $payData = new PayData($this->data['ok_url'], $this->data['cancel_url'], $this->data['ipn_url'], $this->data['store_name'] . ' Order: ' . $this->data['order_id'], $sender, $receivers);
        $payData->setCurrencyCode($this->currencyPaysondirect());
        $payData->setLocaleCode($this->languagePaysondirect());

        if ($invoiceFee && in_array(FundingConstraint::INVOICE, $constraints)) {
            $payData->setInvoiceFee($invoiceFee);
        }
        $payData->setOrderItems($orderItems);

        $showReceiptPage = $this->config->get('payment_paysondirect_receipt');
        $payData->setShowReceiptPage($showReceiptPage);
        if (in_array(FundingConstraint::INVOICE, $constraints)) {
            $this->writeArrayToLog($orderItems, sprintf('Order items sent to Payson, with Payson Invoice as optional payment option. Invoice fee(%sSEK) Total amount(%sSEK).', $this->config->get('total_paysoninvoice_fee_fee'), $this->data['amount']));
        } else {
            $this->writeArrayToLog($orderItems, sprintf('Order items sent to Payson, with Payson direct as payment option, Total amount(%sSEK)', $this->data['amount']));
        }
        

        $payData->setFundingConstraints($constraints);
        $payData->setGuaranteeOffered('NO');
        $payData->setTrackingId($this->data['salt']);

        $payResponse = $this->api->pay($payData);
        
        if ($payResponse->getResponseEnvelope()->wasSuccessful()) {
            return array("Result" => "OK", "PaymentURL" => $this->api->getForwardPayUrl($payResponse));
        } else {
            $errors = $this->logErrorsAndReturnThem($payResponse);
            return array("Result" => "ERROR", "ERRORS" => $errors);
        }
    }

    function logErrorsAndReturnThem($response) {
        $errors = $response->getResponseEnvelope()->getErrors();

        if ($this->config->get('payment_paysondirect_logg') == 1) {
            $this->writeToLog(print_r($errors, true));
        }

        return $errors;
    }

    /**
     * 
     * @param string $message
     * @param PaymentDetails $paymentDetails
     */
    function writeToLog($message, $paymentDetails = False) {
        $paymentDetailsFormat = "Payson reference:&#9;%s&#10;Correlation id:&#9;%s&#10;";
        if ($this->config->get('payment_paysondirect_logg') == 1) {

            $this->log->write('PAYSON&#10;' . $message . '&#10;' . ($paymentDetails != false ? sprintf($paymentDetailsFormat, $paymentDetails->getPurchaseId(), $paymentDetails->getCorrelationId()) : '') . $this->writeModuleInfoToLog());
        }
    }

    private function writeArrayToLog($array, $additionalInfo = "") {
        if ($this->config->get('payment_paysondirect_logg') == 1) {
            $this->log->write('PAYSON&#10;Additional information:&#9;' . $additionalInfo . '&#10;&#10;' . print_r($array, true) . '&#10;' . $this->writeModuleInfoToLog());
        }
    }

    private function writeModuleInfoToLog() {
        return 'Module version: ' . $this->config->get('payment_paysondirect_modul_version') . '&#10;------------------------------------------------------------------------&#10;';
    }

    private function getAPIInstance() {
        require_once 'payson/paysonapi.php';

        $agent = explode('##', $this->config->get('payment_paysondirect_agent_id')); 
        $md5 = explode('##', $this->config->get('payment_paysondirect_md5'));
        $store = $this->config->get('config_store_id');                       
        $agentid = $agent[$store];
        $md5key = $md5[$store];
        $credentials = new PaysonCredentials(trim($agentid), trim($md5key), null, 'PaysonCheckout1.0_Opencart-3-0|' . $this->config->get('payment_paysondirect_modul_version') . '|' . VERSION);

        $api = new PaysonApi($credentials, $this->testMode);

        return $api;
    }

    private function getOrderItems() {
        require_once 'payson/orderitem.php';

        $this->load->language('extension/payment/paysondirect');

        $orderId = $this->session->data['order_id'];

        $order_data = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        $query = "SELECT `order_product_id`, `name`, `model`, `price`, `quantity`, `tax` / `price` as 'tax_rate' FROM `" . DB_PREFIX . "order_product` WHERE `order_id` = " . (int) $orderId . " UNION ALL SELECT 0, '" . $this->language->get('text_gift_card') . "', `code`, `amount`, '1', 0.00 FROM `" . DB_PREFIX . "order_voucher` WHERE `order_id` = " . (int) $orderId;
        $product_query = $this->db->query($query)->rows;

        foreach ($product_query as $product) {

            $productOptions = $this->db->query("SELECT name, value FROM " . DB_PREFIX . 'order_option WHERE order_id = ' . (int) $orderId . ' AND order_product_id=' . (int) $product['order_product_id'])->rows;
            $optionsArray = array();
            if ($productOptions) {
                foreach ($productOptions as $option) {
                    $optionsArray[] = $option['name'] . ': ' . $option['value'];
                }
            }
				
            $productTitle = $product['name'];

            if (!empty($optionsArray))
                $productTitle .= ' | ' . join('; ', $optionsArray);

            $productTitle = (strlen($productTitle) > 80 ? substr($productTitle, 0, strpos($productTitle, ' ', 80)) : $productTitle);
            
				
            $product_price = $this->currency->format($product['price'] * 100, $order_data['currency_code'], $order_data['currency_value'], false) / 100;

            $this->data['order_items'][] = new OrderItem(html_entity_decode($productTitle, ENT_QUOTES, 'UTF-8'), $product_price, $product['quantity'], $product['tax_rate'], $product['model']);
        }

        $orderTotals = $this->getOrderTotals();

        foreach ($orderTotals as $orderTotal) {
            $orderTotalAmount = $this->currency->format($orderTotal['value'] * 100, $order_data['currency_code'], $order_data['currency_value'], false) / 100;
            $this->data['order_items'][] = new OrderItem(html_entity_decode($orderTotal['title'], ENT_QUOTES, 'UTF-8'), $orderTotalAmount, 1, $orderTotal['lpa_tax'] / 100, $orderTotal['code']);
        }

        return $this->data['order_items'];
    }

    private function getOrderTotals() {
      // Totals
        $this->load->model('setting/extension');
        $totals = array();
        $taxes = $this->cart->getTaxes();
        $total = 0;

        // Because __call can not keep var references so we put them into an array.
        $total_data = array(
            'totals' => &$totals,
            'taxes' => &$taxes,
            'total' => &$total
        );

        $old_taxes = $taxes;
        $lpa_tax = array();

        $sort_order = array();

        $results = $this->model_setting_extension->getExtensions('total');
        
        foreach ($results as $key => $value) {
            if (isset($value['code'])) {
                $code = $value['code'];
            } else {
                $code = $value['key'];
            }

            $sort_order[$key] = $this->config->get('total_' . $code . '_sort_order');
        }

        array_multisort($sort_order, SORT_ASC, $results);

        foreach ($results as $result) {
            if (isset($result['code'])) {
                $code = $result['code'];
            } else {
                $code = $result['key'];
            }

            if ($this->config->get('total_' . $code . '_status')) {
                $this->load->model('extension/total/' . $code);

                // We have to put the totals in an array so that they pass by reference.
                $this->{'model_extension_total_' . $code}->getTotal($total_data);

                if (!empty($totals[count($totals) - 1]) && !isset($totals[count($totals) - 1]['code'])) {
                    $totals[count($totals) - 1]['code'] = $code;
                }

                $tax_difference = 0;

                foreach ($taxes as $tax_id => $value) {
                    if (isset($old_taxes[$tax_id])) {
                        $tax_difference += $value - $old_taxes[$tax_id];
                    } else {
                        $tax_difference += $value;
                    }
                }

                if ($tax_difference != 0) {
                    $lpa_tax[$code] = $tax_difference;
                }

                $old_taxes = $taxes;
            }
        }

        $sort_order = array();

        foreach ($totals as $key => $value) {
            $sort_order[$key] = $value['sort_order'];

            if (isset($lpa_tax[$value['code']])) {
                $total_data['totals'][$key]['lpa_tax'] = abs($lpa_tax[$value['code']] / $value['value'] * 100);
            } else {
                $total_data['totals'][$key]['lpa_tax'] = 0;
            }
        }

        $ignoredTotals = $this->config->get('payment_paysondirect_ignored_order_totals');
        if ($ignoredTotals == null)
            $ignoredTotals = 'sub_total, total, tax';

        $ignoredOrderTotals = array_map('trim', explode(',', $ignoredTotals));
        foreach ($totals as $key => $orderTotal) {
            if (in_array($orderTotal['code'], $ignoredOrderTotals)) {
                unset($totals[$key]);
            }
        }
        
        return $totals;
    }

    function paysonIpn() {
        $this->load->model('checkout/order');
        $postData = file_get_contents("php://input");

        $orderId = 0;

        // Set up API
        // Validate the request
        $response = $this->api->validate($postData);
        //OBS!  token �r samma i ipn och return
        if ($response->isVerified()) {
            // IPN request is verified with Payson
            // Check details to find out what happened with the payment
            $salt = explode("-", $response->getPaymentDetails()->getTrackingId());

            if ($salt[0] == (md5($this->config->get('payment_paysondirect_secure_word')) . '1')) {
                $orderId = $salt[count($salt) - 1];

                $this->storeIPNResponse($response->getPaymentDetails(), $orderId);


                $this->handlePaymentDetails($response->getPaymentDetails(), $orderId, true);
            } else
                $this->writeToLog('The secure word could not be verified.', $response->getPaymentDetails());
        } else
            $this->writeToLog('The IPN response from Payson could not be validated.', $response->getPaymentDetails());
    }

    /**
     * 
     * @param PaymentDetails $paymentDetails
     * @param int $orderId
     */
    private function storeIPNResponse($paymentDetails, $orderId) {

        $this->db->query("INSERT INTO " . DB_PREFIX . "payson_order SET 
                            order_id                      = '" . $orderId . "', 
                            valid                         = '" . 1 . "', 
                            added                         = NOW(), 
                            updated                       = NOW(), 
                            ipn_status                    = '" . $paymentDetails->getStatus() . "',     
                            sender_email                  = '" . $paymentDetails->getSenderEmail() . "', 
                            currency_code                 = '" . $paymentDetails->getCurrencyCode() . "',
                            tracking_id                   = '" . $paymentDetails->getTrackingId() . "',
                            type                          = '" . $paymentDetails->getType() . "',
                            purchase_id                   = '" . $paymentDetails->getPurchaseId() . "',
                            invoice_status                = '" . $paymentDetails->getInvoiceStatus() . "',
                            customer                      = '" . $paymentDetails->getCustom() . "', 
                            shippingAddress_name          = '" . $paymentDetails->getShippingAddressName() . "', 
                            shippingAddress_street_ddress = '" . $paymentDetails->getShippingAddressStreetAddress() . "', 
                            shippingAddress_postal_code   = '" . $paymentDetails->getShippingAddressPostalCode() . "', 
                            shippingAddress_city          = '" . $paymentDetails->getShippingAddressPostalCode() . "', 
                            shippingAddress_country       = '" . $paymentDetails->getShippingAddressCity() . "', 
                            token                         =  '" . $paymentDetails->getToken() . "'"
        );
    }

    public function languagePaysondirect() {
        switch (strtoupper($this->data['language_code'])) {
            case "SE":
            case "SV":
                return "SV";
            case "FI":
                return "FI";
            default:
                return "EN";
        }
    }

    public function currencyPaysondirect() {
        switch (strtoupper($this->data['currency_code'])) {
            case "SEK":
                return "SEK";
            default:
                return "EUR";
        }
    }

    public function paysonApiError($error) {
        $this->load->language('extension/payment/paysondirect');
        $error_code = '<html>
                            <head>
                                <script type="text/javascript"> 
                                    alert("' . $error . $this->language->get('text_payson_payment_method') . '");
                                    window.location="' . (HTTPS_SERVER . 'index.php?route=checkout/checkout') . '";
                                </script>
                            </head>
                    </html>';
        echo ($error_code);
        exit;
    }

}

?>